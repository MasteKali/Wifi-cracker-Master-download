Beta version is currently being worked on. 

Min API 4.0 

New Features

-Packet Sniffing 

-Password cracking from packets

-Reports



The Beta version is for educational purposes only. Bad Apps Development and myself are not responsible for what you do with this application. 
