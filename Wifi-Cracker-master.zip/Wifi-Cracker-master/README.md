<p align="center">
  <img src=https://github.com/themrbigfoot/Wifi-Cracker/blob/master/web_hi_res_512.png height="350" width="350" title="hover text">
</p>

Wifi-Cracker
============

## Usage
You only need to download the .APK file and install it on your mobile device. You will need to allow third party applications before downloading and installing. 

## Step 1: before using this application you have to FORGET your current wifi connection other the scan will not work and you will be unable to attempt a connection. 

## Step 2: Before you can view any networks around you, you must enable location services through your settings. New android permissions require location services due to the network dealing with IP addresses. 


Description
------------
Wifi Cracker is a great tool to use if you have forgotten your wifi password and need to figure it out. This application works well with WEP, WPA, WPA-PSK security types. There is a default wordlist that you can use to guess your password, however if you would like to use your own wordlist to guess your password then you can simply follow the directions to add your own wordlist you're off to the races.
Features:
Help website included for tips on how to use Wifi Cracker
Recover lost wifi password
Security types WEP, WPA, WPA-PSK
Use a custom wordlist to let you guess as many passwords as you want

Additional Information
------------
### oldAPK <br>
Version: 0.1<br>
Platform: Android <br>
Min Android: 2.2 <br>
Size: N/A <br>

### newAPK(Current BETA Testing) <br>
Version: 0.1<br>
Platform: Android <br> 
Min Android 28 <br>
Size: N/A <br>


Permissions
------------
<code>ACCESS_WIFI_STATE</code> Allows application to check if your password guess was correct<br>
<code>ACCESS_NETWORK_STATE</code> Allows application to check if your password guess was correct<br>
<code>CHANGE_WIFI_STATE</code> if password guess was correct, lets application change your current wifi connection <br>
<code>WRITE_EXTERNAL_STORAGE</code> Allows you to import a custom wordlist <br>
<code>INTERNET</code> if password guess correct, check internet connection to double check wifi connection <br>

Device Toggling
-------------
Android 10 and higher:

The same throttling limits from Android 9 apply. There is a new developer option to toggle the throttling off for local testing (under Developer Options > Networking > Wi-Fi scan throttling).

Feedback(Please provide)
------------



Email: trevatk55@gmail.com
